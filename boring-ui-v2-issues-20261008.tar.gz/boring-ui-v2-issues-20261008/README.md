# boring-ui v2 issue archive

Snapshot of all accessible issues from `hachej/boring-ui`, taken October 8, 2026. Original issues and PR branches were not modified.

403 issues: 23 open, 380 closed. 711 comments. 6394 timeline events.

- [Manifest](manifest.json)
- [Checksums](SHA256SUMS)
- Raw API records are under `raw/`; descriptions and full comments are in each Markdown issue below.

This preserves current bodies, authors, timestamps, labels, assignees, states, closure reasons, comments and API-visible timelines, including linked PR references. Earlier edited body versions and deleted/redacted GitHub content are not available through this export. No GitHub attachment URLs were found in issue/comment bodies. Other external links remain links; their destination contents are not mirrored.

## Issues

| Issue | State | Title |
| --- | --- | --- |
| [#5](issues/0005.md) | closed | arch: migrate event bus to composition-time typing |
| [#6](issues/0006.md) | closed | Better file loader |
| [#7](issues/0007.md) | closed | User question pane |
| [#8](issues/0008.md) | closed | Image upload: save as file instead of base64 inline |
| [#11](issues/0011.md) | closed | Add idempotent workspace runtime refresh flow |
| [#12](issues/0012.md) | closed | Epic: agent harness pluggability and Pi refactor |
| [#14](issues/0014.md) | closed | Plan harness-scoped follow-up capabilities |
| [#16](issues/0016.md) | closed | Add Bedrock Agent sandbox compatibility |
| [#19](issues/0019.md) | closed | Refactor ChatPanel pi-native follow-up/projection logic into focused hooks |
| [#21](issues/0021.md) | closed | Extract core-neutral workspace catalog routes for CLI/local reuse |
| [#22](issues/0022.md) | closed | Refactor pi chat projection into shared helper |
| [#26](issues/0026.md) | closed | Move @file mentions from agent into workspace composer provider |
| [#27](issues/0027.md) | closed | Refactor PostgresWorkspaceStore into focused store modules |
| [#28](issues/0028.md) | closed | Split Pi coding-agent harness into focused adapter modules |
| [#29](issues/0029.md) | closed | Move DataExplorer out of base front components into plugin primitive area |
| [#31](issues/0031.md) | closed | Publish @hachej/boring-ui-kit stylesheet entry |
| [#32](issues/0032.md) | closed | Hot-reload plugin agent layer |
| [#33](issues/0033.md) | closed | Add tool UI metadata renderer hints |
| [#34](issues/0034.md) | closed | Complete plugin custom tool renderer API |
| [#35](issues/0035.md) | closed | Reload PDF and image panes on file changes |
| [#36](issues/0036.md) | closed | Add tab context menu and sync selected file to file tree |
| [#37](issues/0037.md) | closed | Remove /model slash command |
| [#38](issues/0038.md) | closed | Follow-up: remove playground's direct data-catalog wiring |
| [#39](issues/0039.md) | closed | Follow-up: replace ChatEmptyState arbitrary styling with semantic theme tokens |
| [#41](issues/0041.md) | closed | core: wire /reload + per-workspace hot plugin reload into multi-tenant agent server |
| [#42](issues/0042.md) | closed | audit: consolidate 3 copies of data-pi-* event parsing into shared module |
| [#43](issues/0043.md) | closed | audit: consolidate duplicated localStorage persistence between useAgentChat and piChatProjection |
| [#44](issues/0044.md) | closed | audit: split ChatPanel.tsx (~1932 lines) into focused modules |
| [#45](issues/0045.md) | closed | audit: split prompt-input.tsx (~1149 lines) without breaking primitive exports |
| [#46](issues/0046.md) | closed | audit: split createHarness.ts (~1208 lines) into focused harness modules |
| [#47](issues/0047.md) | closed | audit: remove dead exports from primitives/index.ts and bareToolRenderers |
| [#48](issues/0048.md) | closed | audit: piChatProjection.ts handleData() if-else → dispatch table |
| [#49](issues/0049.md) | closed | audit: remove unused onUploadFile prop from ChatPanel |
| [#51](issues/0051.md) | closed | Onboarding plugin: zero-friction LLM auth across CLI, full-app, and child apps |
| [#52](issues/0052.md) | closed | Explore pi-native wire protocol to simplify chat panel + tool wiring |
| [#53](issues/0053.md) | closed | v2: plugin Pi lifecycle hooks with in-process runtime closures |
| [#54](issues/0054.md) | closed | Make the agent (chat) panel collapsible |
| [#55](issues/0055.md) | closed | Add user-facing Skill & Plugin explorer to the left rail |
| [#56](issues/0056.md) | closed | Move ask-user tool to Pi extension with workspace-aware session bridge |
| [#57](issues/0057.md) | closed | README demo video asset |
| [#61](issues/0061.md) | closed | Add static CLI asset endpoint for runtime plugin front hot reload |
| [#64](issues/0064.md) | closed | Ensure generated plugins use boring-ui primitives from the runtime |
| [#66](issues/0066.md) | closed | Vercel sandbox Python provisioning leaves bm/venv broken |
| [#67](issues/0067.md) | closed | Agent UI: opening a folder should focus it in file tree, not open a pane |
| [#68](issues/0068.md) | closed | Future: add workspace provisioning lease for multi-user/cloud concurrency |
| [#69](issues/0069.md) | closed | Workspace tab context menu: add Copy Path and Close Other Tabs |
| [#75](issues/0075.md) | closed | feat(workspace): add refresh button to HTML viewer |
| [#82](issues/0082.md) | closed | Agent chat: Stop button discards queued message instead of sending it |
| [#83](issues/0083.md) | closed | Workspace file tree: folder deletion not working |
| [#95](issues/0095.md) | closed | Deferred dependency major migrations |
| [#108](issues/0108.md) | closed | Polish workspace top bar alignment |
| [#109](issues/0109.md) | closed | Re-resolve open file panes after workspace plugin reload |
| [#121](issues/0121.md) | closed | Add shortcuts for model picker and model selection |
| [#122](issues/0122.md) | closed | Add doc annotation feature for review workflows |
| [#123](issues/0123.md) | closed | Track auto-creation of reusable base runtime after first fallback provisioning |
| [#125](issues/0125.md) | closed | New slash command: /feedback — auto-create GitHub issue with session transcript + session ID |
| [#127](issues/0127.md) | closed | Plan: credit-based / token-usage billing (Stripe) in core |
| [#128](issues/0128.md) | closed | Filetree filter returns 0 results with no empty state |
| [#132](issues/0132.md) | closed | Workspace reload shows only the compacted tail of long sessions, not the full transcript |
| [#145](issues/0145.md) | closed | Evaluate Mirage for browser-native coding workspace / agent UX |
| [#147](issues/0147.md) | closed | Plan cron execution and monitoring plugin for Boring UI |
| [#148](issues/0148.md) | closed | Plan monitoring plugin for Boring UI |
| [#149](issues/0149.md) | closed | Esc during chat should stop chat, not close workspace |
| [#154](issues/0154.md) | closed | CLI direct mode should allow opening files outside workspace |
| [#160](issues/0160.md) | closed | Copy icon in markdown message is not working |
| [#173](issues/0173.md) | closed | Add opt-in visual artifacts for runtime plugin test command |
| [#174](issues/0174.md) | closed | Make slash commands mentioned in agent text clickable |
| [#178](issues/0178.md) | closed | Show edit tools expanded with a delta visualization |
| [#181](issues/0181.md) | closed | Add workspace secret management for runtime plugins |
| [#183](issues/0183.md) | closed | boring-ui-plugin test should open panel before returning no-browser-connected |
| [#187](issues/0187.md) | closed | Add session status visibility to session list |
| [#188](issues/0188.md) | closed | Add agent completion and attention notifications |
| [#189](issues/0189.md) | closed | Show current Git branch for Git-backed workspaces |
| [#190](issues/0190.md) | closed | Fix chat panel vertical scroll to use full pane height |
| [#192](issues/0192.md) | closed | Make empty chat proposals stack on narrow chat panels |
| [#197](issues/0197.md) | closed | Create Boring Claw plugin for recurring jobs and GitHub issue auto-picker |
| [#199](issues/0199.md) | closed | File tree context menu is hidden for bottom rows |
| [#200](issues/0200.md) | closed | Local .agents/skills skills do not appear in slash-command list |
| [#202](issues/0202.md) | closed | File tree does not auto-detect newly-created files across runtime modes |
| [#203](issues/0203.md) | closed | Add word counter to Markdown editor |
| [#204](issues/0204.md) | closed | Add Close all action to tab right-click menu |
| [#211](issues/0211.md) | closed | Add clickable workspace links to open specific session history |
| [#213](issues/0213.md) | closed | Browser tab title should include active workspace name |
| [#214](issues/0214.md) | closed | Add Copy Git URL action to file tree context menu |
| [#220](issues/0220.md) | closed | Add right-click file download action |
| [#221](issues/0221.md) | closed | Add drag-and-drop file upload to workspace |
| [#222](issues/0222.md) | closed | Evaluate pg_durable for durable workflow support in boring-ui-v2 |
| [#223](issues/0223.md) | closed | Evaluate external runtime/provider candidates for boring-ui-v2 (forkd umbrella) |
| [#224](issues/0224.md) | closed | Add /reload result to LLM context |
| [#226](issues/0226.md) | closed | Integrate Tiptap collaboration for workspace editors |
| [#228](issues/0228.md) | closed | Implement native Pi TUI slash commands in boring-ui |
| [#233](issues/0233.md) | closed | Pi-native chat: image attachments don't render in loaded history (de-inlined by pi) |
| [#238](issues/0238.md) | closed | Dedupe theme palette onto ui-kit tokens.css (workspace import + agent drift guard) |
| [#239](issues/0239.md) | closed | Retire the UIMessageChunk harness stream (sendMessage) — zero production callers |
| [#242](issues/0242.md) | closed | Post-#241 simplification backlog: agent package lean-down follow-ups |
| [#243](issues/0243.md) | closed | Deep-linkable chat sessions: put the active session id in the URL (workspace mode) |
| [#250](issues/0250.md) | closed | refactor(cli): decompose pluginFrontRuntime.ts (1946 lines) |
| [#254](issues/0254.md) | closed | Consolidate workspaces-mode plugin runtime onto a shared per-workspace unit |
| [#256](issues/0256.md) | closed | Add Skill & Plugin edition pane |
| [#257](issues/0257.md) | closed | Add browser-native screenshot copy to HTML viewer |
| [#258](issues/0258.md) | closed | Specify optional trusted browser-use plugin |
| [#267](issues/0267.md) | closed | Perf: workbench visible in <1s warm — stop booting the whole chat/editor world upfront |
| [#276](issues/0276.md) | closed | Chat pane scroll resets to top when switching panes |
| [#283](issues/0283.md) | closed | Add pane context menu action to open in standalone browser tab |
| [#295](issues/0295.md) | closed | Plan: evaluate Pierre Trees replacement for workspace file tree |
| [#307](issues/0307.md) | closed | Harden remote-worker sandbox: gVisor + per-workspace network isolation on Fly |
| [#308](issues/0308.md) | closed | Dark-mode token mismatch: core keys [data-theme=dark], agent/workspace key .dark → white-on-white buttons in the agent subtree |
| [#318](issues/0318.md) | closed | Explore Electron desktop wrapper for boring-ui CLI |
| [#328](issues/0328.md) | closed | Add Remotion Studio embed plugin |
| [#357](issues/0357.md) | closed | State of work: remote-sandbox-safe hosted external plugins |
| [#358](issues/0358.md) | closed | Visualize markdown frontmatter above viewer |
| [#361](issues/0361.md) | closed | Epic: Multi-project left bar (layout modes + Projects nav) |
| [#362](issues/0362.md) | closed | PR1 — Layout-mode seam (dropdown unchanged, no visible change) |
| [#363](issues/0363.md) | closed | PR2 — Multi-project inline left bar (Projects nav + cross-project pin) |
| [#367](issues/0367.md) | closed | Plan: TipTap-first agentic markdown collaboration |
| [#371](issues/0371.md) | closed | Handle Codex context_length_exceeded during compaction/continue |
| [#375](issues/0375.md) | closed | Feedback: link popup button has white text on white background |
| [#376](issues/0376.md) | closed | Plan shared child-app platform |
| [#377](issues/0377.md) | closed | Multi-project left bar: browse sessions across projects without loading + pinned projects + design polish |
| [#379](issues/0379.md) | closed | Integrate Pi-native content search into Boring session history |
| [#380](issues/0380.md) | closed | Allow external harnesses to create review/question hooks |
| [#381](issues/0381.md) | closed | Feedback: GTM plugin inspired by La Growth Machine |
| [#391](issues/0391.md) | closed | Domain-routed agent workspaces, then multi-agent and runtime expansion |
| [#396](issues/0396.md) | closed | Chat scrolling optimization: reader-first streaming experience |
| [#397](issues/0397.md) | closed | Plan Seneca task and background-agent control plane |
| [#398](issues/0398.md) | closed | Make app-left pane composable/editable for plugins and non-agent tools |
| [#399](issues/0399.md) | closed | Create @hachej/boring-control-plane package for Seneca supervision |
| [#416](issues/0416.md) | closed | Add explicit multi-filesystem contract for boring-bash and governed context |
| [#417](issues/0417.md) | closed | Explore Claude Code CLI subscription-backed harness |
| [#421](issues/0421.md) | closed | Add public Markdown share links for CLI review |
| [#467](issues/0467.md) | closed | Show file name tooltip on file-tree hover |
| [#468](issues/0468.md) | closed | Add copy/open hover actions for URLs in chat |
| [#473](issues/0473.md) | closed | Make app left pane controls composable for host explorers |
| [#475](issues/0475.md) | closed | Add company admin controls for context and model access |
| [#485](issues/0485.md) | closed | Allow PowerPoint and Excel editing from boring-ui |
| [#526](issues/0526.md) | closed | Office in-app agent surface: adopt pi-for-excel + boring connector, fork for PowerPoint (Word later) |
| [#541](issues/0541.md) | closed | Add explicit Claude subscription auth for CLI mode |
| [#551](issues/0551.md) | closed | Build a maintainable Boring wrapper for pi-for-excel |
| [#567](issues/0567.md) | closed | Plan Markdown embedded plugin nodes |
| [#579](issues/0579.md) | closed | Add dictate button with automatic transcript insertion to composer |
| [#580](issues/0580.md) | closed | Make the app UI responsive and readable on phones |
| [#590](issues/0590.md) | closed | Add boring-automation plugin for scheduled prompt sessions |
| [#594](issues/0594.md) | closed | Add shared session rename and agent session management |
| [#601](issues/0601.md) | closed | WorkspaceAgentFront: provisionWorkspace=false disables remote chat sessions |
| [#609](issues/0609.md) | closed | #594 Shared native session rename |
| [#610](issues/0610.md) | closed | #594 Agent session management |
| [#611](issues/0611.md) | closed | #594 Project-wide session activity read model |
| [#612](issues/0612.md) | closed | #594 CLI task session bindings and inline task-card sessions |
| [#613](issues/0613.md) | closed | #594 Task active-agent indicators |
| [#614](issues/0614.md) | closed | #594 Hosted Postgres task-session bindings |
| [#633](issues/0633.md) | closed | Replace Pi session wrappers with durable session metadata index |
| [#636](issues/0636.md) | closed | Agent consumption contract & multi-agent consumption (Decision 22 implementation) |
| [#637](issues/0637.md) | closed | Close app-left overlay when opening a session |
| [#709](issues/0709.md) | closed | Replace Pi-visible session wrappers with native IDs and private metadata index |
| [#737](issues/0737.md) | closed | flaky e2e: 'Stop' locator strict-mode collision in pi-native-property-baseline |
| [#747](issues/0747.md) | closed | #709 Pi SDK native-ID and shared-directory compatibility gate |
| [#748](issues/0748.md) | closed | #709 Local ephemeral draft and native-ID materialization protocol |
| [#749](issues/0749.md) | closed | #709 Native Pi list/search canonicalization and Boring ID consumer migration |
| [#750](issues/0750.md) | closed | #709 Crash-safe local legacy wrapper migration and Pi CLI parity |
| [#751](issues/0751.md) | closed | #709 Hosted metadata adapter, scoped migration, and legacy-wrapper retirement |
| [#757](issues/0757.md) | closed | Published @hachej/boring-workspace lacks standalone build scripts (factory consuming-repo gap) |
| [#762](issues/0762.md) | closed | #709 Browser-only New chat draft UX |
| [#763](issues/0763.md) | closed | #709 Direct-local native first-send without wrapper |
| [#764](issues/0764.md) | closed | #709 Native-session capability and direct-local admission |
| [#765](issues/0765.md) | closed | #709 Private metadata index and native stream/scope migration |
| [#768](issues/0768.md) | closed | Flaky test: d1CommandCli signal-timing race (latched signal after leader exit) |
| [#769](issues/0769.md) | closed | Route /feedback feature requests to Project backlog drafts |
| [#775](issues/0775.md) | closed | Native Pi session creation and rename |
| [#776](issues/0776.md) | closed | Bind tasks to native Pi session IDs |
| [#778](issues/0778.md) | closed | Pi chat opened from external entrypoint does not auto-create/update session list |
| [#781](issues/0781.md) | closed | Session list status does not update automatically |
| [#784](issues/0784.md) | closed | Feedback skill discovery and chat question focus regressions |
| [#785](issues/0785.md) | closed | D1: add fail-closed isolated authority seam for EU proof execution |
| [#786](issues/0786.md) | closed | Add sessionless Task Inbox artifact review work queue |
| [#788](issues/0788.md) | closed | Workbench "Download" on binary files saves the on-screen text, not the file |
| [#790](issues/0790.md) | closed | Associate workspace layout state with chat sessions |
| [#791](issues/0791.md) | closed | Treat “Extensions reloaded” as a successful plugin reload |
| [#801](issues/0801.md) | closed | Fix Infomaniak provider auth resolution after Pi 0.80.7 upgrade |
| [#805](issues/0805.md) | closed | #391 child: A1 agent authoring active; runtime extraction and environments deferred |
| [#806](issues/0806.md) | closed | #391 child: MCP ingress and shareable artifacts |
| [#807](issues/0807.md) | closed | #391 child: Durable multi-channel agent transport |
| [#808](issues/0808.md) | closed | #391 child: Sandbox provider extraction and S3/FUSE mounts |
| [#809](issues/0809.md) | closed | #391 child: Marketplace, identity, contracting, billing, catalog, and channels |
| [#819](issues/0819.md) | closed | #391 Observability and usage metering for agent workspaces |
| [#820](issues/0820.md) | closed | #391 Model provider key policy: BYOK per workspace vs platform-billed |
| [#829](issues/0829.md) | closed | Build an automated self-improving UI review loop |
| [#842](issues/0842.md) | closed | Add explicit skill-management router |
| [#847](issues/0847.md) | closed | Consolidate agent resources and remove obsolete repository scaffolding |
| [#848](issues/0848.md) | closed | Merge plugin-authoring resources into plugin CLI and retire boring-pi |
| [#851](issues/0851.md) | closed | Remove obsolete deployment ownership after Seneca migration |
| [#856](issues/0856.md) | closed | agent-playground dev script fails from a clean checkout (dts:false wipes types needed by boring-workspace build) |
| [#857](issues/0857.md) | closed | Playground dev servers cannot be started concurrently — shared-package clean-rebuild races corrupt dist/ |
| [#859](issues/0859.md) | closed | File tree does not auto-refresh after agent creates/edits files (vercel-sandbox mode) |
| [#861](issues/0861.md) | closed | Break agent↔sandbox / agent↔bash workspace cycles (hoist shared types) |
| [#863](issues/0863.md) | closed | full-app: automation plugin tab missing — server registers it, front never wires it (server/front default-plugin drift) |
| [#871](issues/0871.md) | closed | review(ui): register automation pane and editor popover |
| [#872](issues/0872.md) | closed | Automation list should update immediately after manual run |
| [#873](issues/0873.md) | closed | CLI ask_user flow should not require refresh / disable refresh while awaiting input |
| [#875](issues/0875.md) | closed | feat(workflow): pilot autoresearch on automation plugin |
| [#877](issues/0877.md) | closed | Decommission legacy Fly.io and Neon hosting safely |
| [#882](issues/0882.md) | closed | Diagram plugin: support tldraw as an alternative to Excalidraw |
| [#883](issues/0883.md) | closed | fix(workspace): clear stale app-left action indicator |
| [#895](issues/0895.md) | closed | Split chat session menu into each session top bar |
| [#896](issues/0896.md) | closed | fix(runtime): run hosted automation schedules internally |
| [#900](issues/0900.md) | closed | Add a thin full-catalog Composio mode to boring-mcp |
| [#903](issues/0903.md) | closed | fix(automation): recover stale hosted runs with leases |
| [#905](issues/0905.md) | closed | Extract multi-Agent Host and Gateway boundary |
| [#909](issues/0909.md) | closed | AgentGateway v0: freeze session gateway contract + canonical createAgentHost() composition |
| [#912](issues/0912.md) | closed | Minimal live transcript with same-chat agent nudges |
| [#913](issues/0913.md) | closed | Add reusable visual report bundle under the UI skill |
| [#932](issues/0932.md) | closed | Persist the BSL Python worker across Data Bridge query batches |
| [#935](issues/0935.md) | closed | Return actionable errors for invalid BSL expression results |
| [#938](issues/0938.md) | closed | Discover and open package-owned skills through readonly resource bindings |
| [#942](issues/0942.md) | closed | Support readonly paths inside the primary workspace filesystem |
| [#972](issues/0972.md) | closed | Adopt a rolling small-fixes batch for maintainer review |
| [#978](issues/0978.md) | closed | Fold detached chat into the pane model so session identity has one store |
| [#979](issues/0979.md) | closed | Give the addressed Agent Gateway a native first-send so the dual prompt path disappears |
| [#989](issues/0989.md) | closed | feat(cli): package Boring UI as a notarizable macOS desktop app |
| [#994](issues/0994.md) | closed | CLI redeploy orphans a workspace's chat sessions (sessions keyed by filesystem path) |
| [#995](issues/0995.md) | closed | Unify file search across readable filesystem roots |
| [#996](issues/0996.md) | closed | Preserve filesystem root selection when opening multi-root files |
| [#997](issues/0997.md) | closed | Expose server capabilities for editable skill sources |
| [#1009](issues/1009.md) | closed | Lane: chat streaming durability (Level B → Level D) |
| [#1010](issues/1010.md) | closed | Lane: BYOK — per-workspace model credentials |
| [#1011](issues/1011.md) | closed | Lane: external MCP — user-registered servers |
| [#1012](issues/1012.md) | closed | Lane: sandbox isolation for untrusted code |
| [#1028](issues/1028.md) | closed | Remove unused MessageTimeline renderer |
| [#1029](issues/1029.md) | closed | Full AgentHost cutover: remove registerAgentRoutes compatibility runtime |
| [#1030](issues/1030.md) | closed | Adopt surface-by-surface UI iteration workflow |
| [#1032](issues/1032.md) | closed | Refine the chat top-bar surface |
| [#1033](issues/1033.md) | closed | Refine the chat composer surface |
| [#1036](issues/1036.md) | closed | Improve terminal chat error presentation and recovery |
| [#1040](issues/1040.md) | closed | fix(cli): refresh sessions after external Pi CLI messages |
| [#1047](issues/1047.md) | closed | Workbench: persistent right rail and inward-opening layout |
| [#1049](issues/1049.md) | closed | Chat session header: compact overflow actions menu |
| [#1050](issues/1050.md) | closed | Preserve PAYMENT_REQUIRED before AgentHost effect begins |
| [#1051](issues/1051.md) | closed | Chat pane: hide close action on the final session |
| [#1054](issues/1054.md) | closed | docs: add tangible progress and honest credit rules to AGENTS.md |
| [#1056](issues/1056.md) | closed | Define Workspace, Project, Environment, Session, and filesystem authority boundaries |
| [#1060](issues/1060.md) | closed | Complete addressed multi-Agent UI and remaining post-AgentHost Wave 1 guarantees |
| [#1062](issues/1062.md) | closed | Navigation/session rail: hierarchy, states, and interaction polish |
| [#1064](issues/1064.md) | closed | docs: update GPT-5.6 Luna and Terra model routing |
| [#1068](issues/1068.md) | closed | Plan the Boring software factory operating model |
| [#1069](issues/1069.md) | closed | Unify workspace loading states and startup transitions |
| [#1070](issues/1070.md) | closed | Stream composer dictation live and benchmark French ASR backends |
| [#1072](issues/1072.md) | closed | Add Boring factory agents and Beads Tasks integration |
| [#1073](issues/1073.md) | closed | Polish workspace command palette to AAA quality |
| [#1076](issues/1076.md) | closed | Polish new-chat empty state and composer to AAA quality |
| [#1078](issues/1078.md) | closed | Polish chat transcript and message rendering to AAA quality |
| [#1081](issues/1081.md) | closed | Epic: sandbox worker runtime — salvage SBX1.3 (Docker+runsc session-lifetime) |
| [#1082](issues/1082.md) | closed | Epic: BYOK tenant keys — salvage 16f.2 vault storage (KMS backend) |
| [#1083](issues/1083.md) | closed | Workspace pane: open a running playground on a worktree (Environment lease per pane) |
| [#1084](issues/1084.md) | closed | Outreach links for anonymous leads (idea, from stale PR #352) |
| [#1086](issues/1086.md) | closed | Design inline agent questions and a dedicated Inbox review pane |
| [#1087](issues/1087.md) | closed | Add Workspace MCP grants per Agent |
| [#1092](issues/1092.md) | closed | Exact-SHA release candidate + atomic tag binding (was #1060 slice 4) |
| [#1093](issues/1093.md) | closed | Hermetic dev-login + deterministic dev smoke (was #1060 slice 3) |
| [#1094](issues/1094.md) | closed | Adopt conditional Questionnaire UX for ask_user |
| [#1095](issues/1095.md) | closed | Agent-level details, capabilities, and access inspection |
| [#1100](issues/1100.md) | closed | Agent Details phase 1: secure static configuration inspection |
| [#1106](issues/1106.md) | closed | Epic: production fleet loader + factory seams (multi-agent activation) |
| [#1107](issues/1107.md) | closed | Epic: agent definition as plugin package (agent = installable, versioned, trusted) |
| [#1110](issues/1110.md) | closed | Epic: UI surface optimization loop (factory-run) |
| [#1117](issues/1117.md) | closed | Multi-agent UI: collapsible Agents menu with per-agent cards (owner spec, fleet test 2026-08-06) |
| [#1121](issues/1121.md) | closed | Tech watch: durable-actor runtime for agent sessions (celld / Durable-Objects class) |
| [#1123](issues/1123.md) | closed | Epic: executable environments — per-agent fs + exec grants (configurable multi-root execution) |
| [#1124](issues/1124.md) | closed | Clinic: automatically start and stop Exoscale transcription GPU |
| [#1125](issues/1125.md) | closed | Epic: automation run leases — reclaim orphaned hosted runs safely (multi-replica) |
| [#1127](issues/1127.md) | closed | Epic: external channels — consume agents from WhatsApp/email/SMS (channel adapters over durable streams) |
| [#1129](issues/1129.md) | closed | Epic: MCP ingress — external agents consume a boring-ui workspace (un-dark /mcp/managed-agent) |
| [#1159](issues/1159.md) | closed | e2e instability: pi-native-harness-baseline active-reload timeline hydration destabilized by 6b451336f (gh-1117 agents section) |
| [#1160](issues/1160.md) | closed | [epic #1110] Agents section mobile touch targets under 44px (exempted in #1158, needs real fix) |
| [#1167](issues/1167.md) | closed | [epic #1081] remote-worker nonce store: per-tenant sub-budget (cross-tenant DoS, LOW) + SBX1.4/1.5 audit hand-offs |
| [#1171](issues/1171.md) | closed | Agent details: Reload agent affordance after editing persona instructions |
| [#1177](issues/1177.md) | closed | Epic: visual project documentation — structure, connectors, flows at a glance |
| [#1184](issues/1184.md) | closed | Adopt present-pr artifacts as the standard review-handover deliverable |
| [#1185](issues/1185.md) | closed | Remove runtime-identity v1 migration seam once all deployments have migrated (transitional code, D10) |
| [#1186](issues/1186.md) | closed | Agent knowledge should be a distinct, agent-scoped filesystem |
| [#1187](issues/1187.md) | closed | Epic: migrate the Boring Factory onto the boring-ui CLI workspace (dogfood the product) |
| [#1189](issues/1189.md) | closed | Resolve Agent instruction refs per request so CLI hub mode gets working links |
| [#1190](issues/1190.md) | closed | [epic #1110] Surface: unify pane-resizer UX across all split surfaces |
| [#1191](issues/1191.md) | closed | Clarify ambient context files: local hosts should read AGENTS.md like a pi agent |
| [#1195](issues/1195.md) | closed | [epic #1187] Fleet seats can only resolve Anthropic models — MODEL_TIER_CANDIDATES has no other provider |
| [#1196](issues/1196.md) | closed | [epic #1187] One bad symlink in ~/.pi/agent/skills blanket-500s every agent-scoped route — skip + surface instead of failing all |
| [#1197](issues/1197.md) | closed | [epic #1187] Workspaces mode publishes no persona instruction links — every seat loses its Open button |
| [#1198](issues/1198.md) | closed | [epic #1081] tie sandbox credential-ref wire schema to agent contract at compile time |
| [#1199](issues/1199.md) | closed | chore(test): createAgentHost insufficient-credit replay test flakes under parallel load (5s timeout) |
| [#1201](issues/1201.md) | closed | Model tier→candidate mapping must be deployment config, not hardcoded (MODEL_TIER_CANDIDATES) |
| [#1206](issues/1206.md) | closed | [gh-1184] workspace HTML viewer: render mermaid blocks (present-pr context diagrams show as source) |
| [#1207](issues/1207.md) | closed | [gh-1187] CLI front never passes addressedAgentSelection — Inbox can't open fleet-seat sessions |
| [#1208](issues/1208.md) | closed | [gh-1187] beads adapter: list call fetches no parent/epic edges (B1) + hub never wires beadsOperations (B2) |
| [#1223](issues/1223.md) | closed | Retire BORING_AGENT_FLEET flag → config-presence-driven composition + document local-vs-hosted split |
| [#1224](issues/1224.md) | closed | Epic: ad-hoc audio transcription — batch mode for the transcription service (streaming exists) |
| [#1226](issues/1226.md) | closed | Epic (REWRITE NEEDED): bounded tool catalog — grant-scoped residency, lexical search, child-call dispatch |
| [#1233](issues/1233.md) | open | DX: reduce onboarding from 6 required concepts to 2 (plus one verified scaffold defect) |
| [#1234](issues/1234.md) | closed | ChatLayout drawers lack dialog semantics (focus trap, Escape, scroll lock) |
| [#1237](issues/1237.md) | closed | Pi resource symlink guard breaks every from-source hub (pnpm node_modules links, global skill symlinks) |
| [#1238](issues/1238.md) | closed | Agent sessions scope-pinned across hub restarts (AGENT_SESSION_RUNTIME_SCOPE_MISMATCH) |
| [#1239](issues/1239.md) | closed | Fleet seats never receive workspace plugin agent tools (ask_user) — factory gates cannot be raised by seats |
| [#1240](issues/1240.md) | open | Provider registry: adding a sandbox provider should touch boring-sandbox (+agent) only |
| [#1243](issues/1243.md) | closed | Make BI dashboard browser adapter-driven |
| [#1248](issues/1248.md) | closed | fix(core): persist sandbox handles under canonical workspace UUID |
| [#1250](issues/1250.md) | closed | UI Review reproduce phase races asynchronous workspace readiness |
| [#1251](issues/1251.md) | closed | fix(workspace): clean up left header and remove duplicate chat-header MCP action |
| [#1253](issues/1253.md) | closed | ui-review tooling leaks a mktemp -d per run (thousands of /tmp dirs, exhausts tmpfs inodes) |
| [#1254](issues/1254.md) | closed | Dev VM: /tmp needs an aging rule + pnpm store must never live on tmpfs |
| [#1257](issues/1257.md) | closed | Ship generic BSL querying skill with Data Bridge |
| [#1261](issues/1261.md) | closed | Epic: hosted external plugins — user-authored UI + agent, safely (Seneca) |
| [#1262](issues/1262.md) | closed | Package skill prompt paths bypass agent_resources locators |
| [#1265](issues/1265.md) | closed | fix: ask-user bridge 401 strands credit reservation |
| [#1268](issues/1268.md) | closed | Remove legacy global plugin Agent contribution path |
| [#1270](issues/1270.md) | closed | test: exercise ask-user client against production bridge policy |
| [#1271](issues/1271.md) | closed | Polish CLI workspace hard-reload transition |
| [#1274](issues/1274.md) | closed | Hosted delegation: trusted AgentHost-native delegate_task plugin |
| [#1275](issues/1275.md) | closed | Hosted web access: governed request-scoped search and fetch plugin |
| [#1276](issues/1276.md) | closed | Orchestrator agent plugin: dispatch trigger + fleet tool over automation primitives |
| [#1278](issues/1278.md) | closed | Hide single-agent Agent menu in fleet mode |
| [#1280](issues/1280.md) | closed | Stabilize command-palette UI Review exploration and replay identity |
| [#1283](issues/1283.md) | closed | CLI cannot start in a pnpm monorepo folder: pi runtime resolved from the workspace's node_modules |
| [#1285](issues/1285.md) | closed | Remove residual Resource Timing gate from mobile UI Review actions |
| [#1287](issues/1287.md) | closed | Stale-session recovery sends agentTypeId to agent-scoped create endpoint |
| [#1290](issues/1290.md) | closed | Composer shows a stale local model selection, not the model the session is actually using |
| [#1291](issues/1291.md) | closed | Retry Bombadil when Chromium websocket startup times out |
| [#1293](issues/1293.md) | closed | UI Review replay selector rejects the canonical first settled Wait path |
| [#1295](issues/1295.md) | closed | Stop deletes queued messages: user-typed content is lost with no recovery |
| [#1296](issues/1296.md) | closed | Factory workspace shows a generic 'Agent' seat and an Agent nav tab alongside the real fleet |
| [#1297](issues/1297.md) | closed | Opening several files in a row shows only the last one: no tab representation for file surfaces |
| [#1298](issues/1298.md) | closed | Add session context menu with Archive session |
| [#1299](issues/1299.md) | closed | Allow safe workspace artifact links in chat |
| [#1300](issues/1300.md) | closed | Automation-created session is absent from inventory and cannot open |
| [#1303](issues/1303.md) | closed | App is very slow on mobile: 4.3 MB eager entry bundle blocks first interaction |
| [#1304](issues/1304.md) | closed | Handoff UX: agent's final message must list its output artifacts inline (clickable), paired with the ask_user intention |
| [#1306](issues/1306.md) | closed | ask_user: supersede or withdraw stale intentions when re-raising gates |
| [#1307](issues/1307.md) | closed | Session rename does not stick: title reverts to auto-derived name |
| [#1313](issues/1313.md) | closed | Allow safe continuation of chats after runtime configuration changes |
| [#1314](issues/1314.md) | closed | Store the request ledger outside the user workspace |
| [#1321](issues/1321.md) | closed | Add show-me visual explanation skill |
| [#1323](issues/1323.md) | closed | Sending a message is not smooth: no optimistic echo, chat visibly reloads before the message appears |
| [#1328](issues/1328.md) | closed | Data Bridge masks actionable BSL argument validation errors |
| [#1330](issues/1330.md) | closed | Runtime scope pin keys on configuration identity, not authority: local sessions must continue like pi's own |
| [#1337](issues/1337.md) | closed | Inbox shows placeholder titles and drops pending questions (3 of 6 shown) |
| [#1338](issues/1338.md) | closed | Session inventory scans and parses the whole transcript store per request (16s list, 'Preparing workspace' hang) |
| [#1344](issues/1344.md) | closed | Agent edits are invisible in an open Markdown editor |
| [#1346](issues/1346.md) | closed | Plan a single-account LinkedIn inbox plugin with selective Tailscale egress |
| [#1348](issues/1348.md) | open | Pending owner gates are marked abandoned when the hub restarts — the review queue is wiped |
| [#1349](issues/1349.md) | closed | Core: support host-local OAuth callbacks on exact allowed hosts |
| [#1351](issues/1351.md) | closed | CLI release build breaks on agent front subpath aliases |
| [#1353](issues/1353.md) | closed | Main CI blockers prevent publishing the OAuth release |
| [#1355](issues/1355.md) | closed | Plan the persistent multi-project agent Console |
| [#1361](issues/1361.md) | closed | boring-sandbox is never built in CI — source-only consumption depends on tsconfig paths that esbuild also reads |
| [#1390](issues/1390.md) | closed | ui-review: workspace-agent-sidebar spec fails at ensureAgentNavigation on clean main |
| [#1391](issues/1391.md) | closed | Dropdown menus don't close on Escape in real browsers (jsdom hides it) |
| [#1392](issues/1392.md) | closed | ui-kit: shadow-md resolves to a fully transparent shadow in both themes |
| [#1395](issues/1395.md) | closed | Chat: copy/open hover actions for URLs in chat messages |
| [#1398](issues/1398.md) | closed | AgentPage.tsx contains raw NUL bytes — file renders as binary in every git diff |
| [#1399](issues/1399.md) | closed | North star: multi-seat Threads — 1 Thread = 1 job (was: agent channels) |
| [#1402](issues/1402.md) | closed | Unavailable Workspace default Agent must be recoverable from the UI, not a bare 409 |
| [#1413](issues/1413.md) | closed | C5: resume a paused ask_user turn after process restart |
| [#1419](issues/1419.md) | closed | Clarify bash tool scope when first-class filesystem tools are available |
| [#1421](issues/1421.md) | closed | Render explicit failed status in the session list |
| [#1426](issues/1426.md) | closed | New chat should not create an additional split pane |
| [#1429](issues/1429.md) | closed | Archived-chats disclosure is ~20px on touch viewports — violates 44px hard gate, blocks UI Review repo-wide |
| [#1437](issues/1437.md) | open | Trusted immutable snapshot consumer for disposable Worker sandboxes |
| [#1438](issues/1438.md) | closed | Signup funnel blocked: email-template SSR crashes with 'React is not defined' (classic JSX transform in core dist) |
| [#1444](issues/1444.md) | closed | full-app dev: tsx applies classic JSX to cross-package source aliases (cwd-keyed tsconfig resolution) — signup email crash persists in dev only |
| [#1447](issues/1447.md) | closed | Publish official 0.1.106 packages for workspace Agent Seats |
| [#1449](issues/1449.md) | closed | Sign-in always lands on the default workspace — last-selected workspace not restored |
| [#1450](issues/1450.md) | closed | Invite context lost when invitee signs up: SignInPage's Sign-up link drops redirect/invite_token → unwanted default workspace created |
| [#1451](issues/1451.md) | closed | Tasks panel renders at width:0 when editor tabs are open — mounted but invisible |
| [#1452](issues/1452.md) | closed | ?showcase=1: composer permanently disabled with 'session was not found' (seedShowcase never resolves) |
| [#1453](issues/1453.md) | closed | No unarchive/restore affordance for archived sessions |
| [#1459](issues/1459.md) | open | feat(sandbox): qualify native leases across all providers |
| [#1461](issues/1461.md) | closed | ui-review: bombadil replay diverges on workspace-command-palette — candidate button pair swaps availability between record and replay |
| [#1463](issues/1463.md) | closed | Deleting the default workspace bricks the account: auto-recreate collides with idx_workspaces_default_per_user_app (soft-deleted row not excluded) |
| [#1464](issues/1464.md) | closed | Email links don't match SPA routes: invite-accept points at raw API JSON, password-reset lands on a blank page |
| [#1465](issues/1465.md) | closed | Mobile (390x844): unauthenticated auth card renders with zero size — cannot sign in or sign up on mobile |
| [#1466](issues/1466.md) | closed | Workspace UI guards: Leave leaves stale members UI; /settings renders shell + Delete button for non-members |
| [#1467](issues/1467.md) | open | No app-layer brute-force lockout/rate-limit on sign-in (6 wrong passwords → clean 401s, no 429) |
| [#1469](issues/1469.md) | closed | Composer permanently disabled for sessions not created via the primary new-chat flow (sessionAuthorityReady never satisfied without a model) |
| [#1470](issues/1470.md) | closed | 'Start new chat with <Agent>' creates the session but doesn't open/focus it |
| [#1476](issues/1476.md) | open | CI never runs apps/workspace-playground's Playwright suite (e2e job only runs packages/agent's config); multi-agent-addressed-ui.spec.ts is stale |
| [#1488](issues/1488.md) | closed | Creator signup should add creator seat and upgrade existing workspaces |
| [#1489](issues/1489.md) | open | Hosted remote-sandbox live previews resolve localhost in the browser and render blank |
| [#1491](issues/1491.md) | closed | feat(factory): package portable Factory profiles and procedures |
| [#1495](issues/1495.md) | closed | fix(factory): allow addressed trusted loop package in isolated runtimes |
| [#1498](issues/1498.md) | open | feat(workspace): centralize RuntimeWebView projection seam |
| [#1501](issues/1501.md) | closed | fix(factory): ship package-shaped portable profiles |
| [#1508](issues/1508.md) | open | feat(factory): add native Factory playground with loop and Worker sandboxes |
| [#1511](issues/1511.md) | closed | Workspace Files tree omits enrolled agent knowledge roots |
| [#1517](issues/1517.md) | open | [Epic Closure] Finish Factory epics automatically after merge |
| [#1519](issues/1519.md) | closed | Filesystem catalog must bypass browser caches |
| [#1527](issues/1527.md) | open | feat(core): guest / anonymous agent sessions for pre-signup intake |
| [#1528](issues/1528.md) | open | feat(agent): inbound channel adapter seam (WhatsApp / email / webhook → agent session) |
| [#1529](issues/1529.md) | open | feat(core): one-off product purchase + entitlement alongside credit packs |
| [#1530](issues/1530.md) | open | feat(workspace): PDF rendering primitive and signed public file URLs for deliverables |
| [#1531](issues/1531.md) | open | feat(agent): pass a db/app handle to host tools (ToolExecContext) instead of the closure workaround |
| [#1532](issues/1532.md) | open | feat(automation): human review queue semantics (claim / approve / return) for durable runs |
| [#1560](issues/1560.md) | open | [Factory Inbox] Fix legacy ownership visibility and misleading empty question forms |
| [#1562](issues/1562.md) | open | [Native Creation] First Seneca product journey: release, installation, product runtime |
| [#1565](issues/1565.md) | open | [Workbench] Prevent multi-tab HTTP stream starvation from hanging startup |
| [#1593](issues/1593.md) | open | Transcription: durable browser audio capture and offline recovery |
| [#1595](issues/1595.md) | open | Add native tldraw canvas plugin with regular-agent tools |
| [#1598](issues/1598.md) | open | [Composer Slot] Add composerSlot prop to PiChatPanel |
